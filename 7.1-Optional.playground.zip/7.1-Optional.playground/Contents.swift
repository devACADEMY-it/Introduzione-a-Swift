/*:
 # Optional
 
 Il ```type``` _Optional_ si usa in tutte quelle situazioni in cui il valore può essere assente. Possiamo considerare il type Optional come un involucro che contiene un valore (di un type qualsiasi).
 
 Un Optional, quindi, gestisce due possibilità:
 * il valore c'è, e lo si ottiene entraendolo dall'optional
 * il valore non c'è, e lo si gestisce con la parola chiave __nil__
 */
var temperatura: Int? = 30
temperatura = 29
temperatura = 28
temperatura = nil
temperatura = 31
temperatura = nil

if temperatura == nil {
    print("Nessun valore disponibile")
} else {
    print("La temperatura è disponibile")
}

var ciao: String? = "Ciao"
ciao = nil
ciao = "Hello"
