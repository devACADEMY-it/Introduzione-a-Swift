/*:
 # Operatori
 
 * Operatore di *Assegnamento*
 * Operatori *Unari*
 * Operatori *Binari*
 * Operatori *Ternari*
 * Operatori di *Range*
 * Operatori *Avanzati*
 */
let risposta = 42
