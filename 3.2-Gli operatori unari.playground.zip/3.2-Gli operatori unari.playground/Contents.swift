/*:
 # Unary Operators
 
 ## Plus/Minus Operator
 Serve per cambiare segno o dare _simmetria_ al codice.
 */
let tre = 3
let menoTre = -tre
let sei = +6
/*:
 ## Not Operator
 Serve per negare (quindi fare l'inverso) di un valore vero o falso
 */
var isEnable = false
isEnable = !isEnable
/*:
 ## Compound Assignment
 Serve per appunto per *combinare*  l'operatore di assegnamento con un altro operatore.
 */
var a = 1
a += 1
