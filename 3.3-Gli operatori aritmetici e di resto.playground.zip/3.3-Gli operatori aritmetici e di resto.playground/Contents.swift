/*:
 # Binary Operators
 
 ## Operatori Aritmetici
 
 * Addizione ( ````+```` )
 * Sottrazione ( ````-```` )
 * Moltiplicazione ( ````*```` )
 * Suddivisione ( ````/```` )
 
 */
let somma = 25 + 5

let multi = 6 * 2

let valore: Int16 = 200 * 5

let divisione = 9.0 / 4.0















/*:
 ## Operatore di resto
 Si usa il simbolo ( ````%```` ), ritorna il resto di una divisione.
*/
let resto = 9 % 4



