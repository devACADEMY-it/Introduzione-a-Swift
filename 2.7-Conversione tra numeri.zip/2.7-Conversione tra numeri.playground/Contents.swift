/*:
 # Conversione tra numeri
 */
// Int, Int8, Int16, Int32, Int64
var val1: Int8 = Int8.max // Int8.min (-128)
//: * Important:
//: ````val1 = val1 + 1 // ERRORE! ````
// UInt, UInt8, UInt16, UInt32, UInt64
var val2: UInt8 = UInt8.max // UInt8.min (0)
/*:
 ### Somma tra Int8 e UInt8
 */
var somma = Int(val1) + Int(val2)
/*:
 ### Somma tra Int e Double
*/
let tre = 3
let decimal = 0.14
let pi = Double(tre) + decimal
