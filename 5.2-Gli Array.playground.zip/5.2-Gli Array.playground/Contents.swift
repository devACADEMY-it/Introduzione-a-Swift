//: # Gli Array
//: ### Creare un array
let array1 = Array<Int>()
let array2 = [Int]()
let array3: [Int] = []

let array4 = [34, 56, 78, 90.1]














//: ### Modificare un array
var names = [String]()
names.append("Massimo")
names.append("Francesca")
names.append("Paolo")


names += ["Luciano", "Lucia"]
print(names)










//: ### Accedere ai valori di un array
let paolo = names[2]

for nome in names {
    print("Il nome è \(nome)")
}





