/*:
# if else
 Il costrutto ```if else``` è il primo di una serie di istruzioni condizionali dedicati al controllo del flusso.
*/
var temperatura = 6

if temperatura >= 35 {
    print("La temperatura è troppo alta")
} else if temperatura <= 16 {
    print("La temperatura è troppo bassa!!")
} else {
    print("La temperatura è ok")
}
