//: # Le Tuple
let car = ("Opel", "Astra", 1700)

let mod = car.1

let (marca, modello, cilindrata) = car

print(marca)
print(modello)


let car2 = (marca: "Opel", modello: "Insigna", cilindrata: 1700)

print(car2.cilindrata)
