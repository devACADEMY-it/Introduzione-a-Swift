//: # While
var contatore = 0

while contatore < 3 {
    contatore += 1
    print("while \(contatore)")
}
//: # Repeat-While
repeat {
    print("repeat \(contatore)")
    contatore += 1
} while contatore < 3
