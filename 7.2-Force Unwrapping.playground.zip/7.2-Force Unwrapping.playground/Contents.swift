/*:
 # Force Unwrapping
 
 Il __Force Unwrapping__ è l'operazione di estrazione del valore dal type Optional.
 
 */
var nome: String? = "Marco"
nome = nil
nome = "Lucia"

if nome != nil {
    print("Buongiorno \(nome!)")
}
