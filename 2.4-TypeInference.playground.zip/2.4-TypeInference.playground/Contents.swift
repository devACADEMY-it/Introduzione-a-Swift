/*:
 # Type Inference
 
 Type infrence è la deduzione automatica del tipo (type) di un'espressione in un linguaggio di programmazione.
*/
let risposta = 42
var hello = "Hello"

let pi = 3.14

var prova = 22
