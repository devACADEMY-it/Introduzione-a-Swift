/*:
 # Optional Binding
 
 L'__optional binding__ è un tecnica che permette di gestire in maniera più sicura gli _optional_. Di solito si usa questa tecnica allo statement __if__ ma è possibile utilizzarlo anche con il __while__.
 
 */
var nome: String? = "Marco"
nome = nil

if let nomeReale = nome {
    print("Buongiorno \(nomeReale)")
}

let numero = "123"

if let numeroInt = Int(numero) {
    print("Numero \(numeroInt)")
}
