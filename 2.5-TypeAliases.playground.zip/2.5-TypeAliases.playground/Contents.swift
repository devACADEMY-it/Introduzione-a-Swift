/*:
 # Type Aliases
 
 Type Alias permette di definire un sinonimo (un alias) per un un tipo (type) preesistènte.
 */
typealias Money = Double

let tasso: Money = 1.41
