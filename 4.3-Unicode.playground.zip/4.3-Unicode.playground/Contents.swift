/*:
 # Unicode
 
 Unicode è uno standard internazionale di codifica, rappresentazione ed elaborazione di testi. È un sistema che assegna un numero univoco ad ogni carattere usato per la scrittura di testi indipendemente dalla lingua, dalla piattaforma e dal programma.
 */
/*:
 ### Codifica - CODE UNIT
 Dati in formato *Unicode* possono essere codificati in differenti __code unit__. I più usati sono UTF-8 e UTF-16. Interessante sapere che il formato UTF-8 è retro-compatibile con la codifica ASCII.
 */
/*:
 ### Rappresentazione - CODE POINT
 Un *code point* rappresenta un singolo valore Unicode e i valori possibili vanno da __0__ a __0x10FFFF__ che in decimale è __1.114.111__. Solo 137000 code point sono attualmente utilizzati.*/
/*:
 
 ### Unicode in Swift
 Per rappresentare un carattere Unicode in Swift si usa la sintassi *\u{xxxx}* dove xxxx rappresenta un numero esadecimale.
 */
let euro1 = "€"
let euro2 = "\u{20AC}"

let eaccento: Character = "\u{E9}"
let eaccento2: Character = "\u{65}\u{301}"

let cafe1 = "Caf\u{E9}"
let cafe2 = "Caf\u{65}\u{301}"

cafe1.count
cafe2.count

let sonoUguali = cafe1 == cafe2

