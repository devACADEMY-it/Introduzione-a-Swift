/*:
 # Stringhe e caratteri
 
 Le stringhe sono una sequenza di caratteri. Ad esempio "Ciao" è una stringa composta da 4 caratteri. In Swift si usa il type __String__ per rappresentare una qualsiasi stringa e il type __Character__ per rappresentare il singolo carattere.
 
 ## Creare una stringa
 */
let ciao = "Ciao"
let testo = "Questo è un testo lungo e\nvoglio andare a capo"
let lettera = """
Ciao,\
caro amico ti scrivo.
"""

let vuota = ""
let altra = String()

let vuota = altra.isEmpty
