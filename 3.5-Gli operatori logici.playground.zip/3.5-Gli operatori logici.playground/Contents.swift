/*:
 # Operatori logici
 
 * __NOT__  ( ```` !a ```` )
 * __AND__  ( ```` a && b ```` )
 * __OR__  ( ```` a || b ```` )
 
 */
let isEnable = false
let isActive = !isEnable

let testAnd = isActive && isEnable
let testOr = isActive || isEnable

let validPassword = false

let test = (isActive) || (isEnable && validPassword)
