/*:
 # I Numeri
 
 ## Sistemi numerici
 * Numeri decimali
 * Numeri binari (prefisso _0b_)
 * Numeri ottali (prefisso _0o_)
 * Numeri esadecimali (prefisso _0x_)
 */
let v42Decimale = 42
let v42Binario = 0b101010
let v42Ottale = 0o52
let v42Esa = 0x2A








/*:
 ## Esponente
 
 Per definire un eseponente su usa la lettera _e_
*/
let valoreSenzaEsponente = 125.0
let valoreConEsponente = 1.25e2


















/*:
 ## Leggibilità
 
 Per aumentare la leggibilità di un numero è possibile utilizzare un (underscore) _ per separare le migliaia o i millesimi.
 */
let valoreGrande = 12_523_437
let valoreMoltoPiccolo = 0.234_567
