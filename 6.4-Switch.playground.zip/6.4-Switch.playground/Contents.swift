//: # Switch
var carattere: Character = "y"

switch carattere {
case "a", "e", "i", "o", "u":
    print("Hai scelto una vocale")
case "x", "y":
    print("Hai scelto un carattere particolare")
default:
    print("Hai scelto una consonante")
}


var temperatura = 20

switch temperatura {
case 15...20:
   print("La temperatura è ok")
case 21...35:
    print("Fa abbastanza caldo")
case 36..<100:
    print("Fa molto caldo")
case 0..<15:
    print("Fa abbastanza freddo")
default:
    print("La temperatura va bene")
}
