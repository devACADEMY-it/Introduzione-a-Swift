/*:
 # Set
 Un ```set``` è una collezione distinta di valori dello stesso ```type``` senza un ordine predefinito. I set si usano al posto degli ```Array``` quando l'ordine non è importante o quando è necessario gestire una collezione di elementi unici.
 */
var s1 = Set<Int>()
let s2: Set<Int> = [32, 34]

s1.insert(3)
s1.insert(3)
s1.insert(34)

print(s1)
