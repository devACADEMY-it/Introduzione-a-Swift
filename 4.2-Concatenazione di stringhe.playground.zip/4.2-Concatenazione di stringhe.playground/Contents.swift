//: # Concatenare le stringhe
//: ### L'operatore +
let string1 = "Ciao"
let string2 = "Marco"

let ciao = string1 + string2
let ciaoconspazio = string1 + " " + string2


















//: ### L'operatore +=
var domanda = "Come "
domanda += "stai?"

















//: ### Interpolazione di stringhe
let dieci = 10
let venti = "20"

let frase = "Quanti anni hai? Io ho \(dieci) anni e tu? io invece \(venti)"

let domanda1 = "Quanto fa 6 * 7? La risposta è \(6 * 7)"










