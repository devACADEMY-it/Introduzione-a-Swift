/*:
 # Operatori di confronto
 
 * __Uguale a__   ( ```` a == b ```` )
 * __Diverso da__   ( ```` a != b ```` )
 * __Maggiore di__   ( ```` a > b ```` )
 * __Minore di__   ( ```` a < b ```` )
 * __Maggiore o uguale a__   ( ```` a >= b ```` )
 * __Minore o uguale a__   ( ```` a <= b ```` )
 */
