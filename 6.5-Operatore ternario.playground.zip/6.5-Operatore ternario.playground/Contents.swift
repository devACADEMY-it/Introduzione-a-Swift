//: # Operatore Ternario
var sconto = true
var prezzo = 0

if sconto {
    prezzo = 30
} else {
    prezzo = 50
}

prezzo = sconto ? 30 : 50
