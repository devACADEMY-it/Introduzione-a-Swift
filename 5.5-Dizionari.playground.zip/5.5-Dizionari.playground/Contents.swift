/*:
 # Dictionary
 Il dizionario (type ```Dictionary```) è una collezione, non ordinata, di chiave-valore. Ogni valore è quindi associato ad una chiave univoca. Con il dizionario è necessario specificare un _type_ per la chiave e un _type_ per il valore.
 
 ### Creare un dizionario
 */
let d1 = Dictionary<String, Double>()
let d2 = [String: Double]()
let d3: [String: Double] = [:]

let d4 = ["c1": 3, "c2": 5]







//: ### Modificare un dizionario
var d5 = [String: String]()
d5["chiave1"] = "Ciao"
d5["chiave2"] = "mondo"
print(d5)

d5["chiave1"] = "Hello"
print(d5)















//: ### Iterare un dizionario
for (pippo, pluto) in d5 {
    print("k: \(pippo), v: \(pluto)")
}

for value in d5.values {
    print("il valore è \(value)")
}

for key in d5.keys {
    print("la chiave è \(key)")
}

















