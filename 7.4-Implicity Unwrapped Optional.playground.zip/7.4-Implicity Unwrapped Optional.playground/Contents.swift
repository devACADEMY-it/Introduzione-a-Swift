/*:
 # Implicity Unwrapped Optional
 
 Quando è chiaro che un optional avrà sempre un valore dopo la sua prima definizione è comodo poter definire l'optional come __implicitly unwrapped__.
 */
var nome: String! = "Marco"

let benvenuto = "Benvenuto " + nome

print(benvenuto)
