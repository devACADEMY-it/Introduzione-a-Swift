//: # Operatore Nil-coalescing
var nome: String? = "Marco"

var nomeFinale: String

if nome == nil {
    nomeFinale = "Utente Anonimo"
} else {
    nomeFinale = nome!
}

nomeFinale = (nome != nil ? nome! : "Utente anonimo")

nomeFinale = nome ?? "Utente anonimo"
