//: # For-in
let a1 = ["Giacomo", "Lucia", "Luigi"]

for valore in a1 {
    print("Il nome è \(valore)")
}

let d1 = ["c1": "Casa", "c2": "Hotel"]

for (chiave, valore) in d1 {
    print("La chiave è \(chiave) e il valore è \(valore)")
}

for index in 1...5 {
   print("L'indice è \(index)")
}

let max = 10

for i in 1...max {
    print("L'indice è \(i)")
}

for indice in 1..<100 {
    print("Il valore è \(indice)")
}
