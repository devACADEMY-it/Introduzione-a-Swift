/*:
 # Operazioni sui Set
 
 ### Iterare un set
 */
var s1 = Set<String>()
s1.insert("Massimo")
s1.insert("Francesco")
s1.insert("Lucia")
s1.insert("Antonio")

for name in s1 {
    print(name)
}

















//: ### Operazioni speciali sui Set
//: ![Operazioni sui Set](set.png)
let n1: Set<Int> = [1, 2, 5, 8, 9]
let n2: Set<Int> = [3, 5, 9, 10, 11]

n1.intersection(n2)
n1.symmetricDifference(n2)
n1.union(n2)
n1.subtracting(n2)






